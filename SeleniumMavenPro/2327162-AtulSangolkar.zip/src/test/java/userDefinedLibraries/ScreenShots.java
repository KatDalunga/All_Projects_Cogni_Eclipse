package userDefinedLibraries;

import java.io.File;

import java.io.IOException;


import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.google.common.io.Files;

public class ScreenShots {
	public static String filepath1 = "C:\\Users\\2327162\\eclipse-workspace\\SeleniumMavenPro\\ProjectScreenshots\\drag2.png";
	public static String filepath2 = "C:\\Users\\2327162\\eclipse-workspace\\SeleniumMavenPro\\ProjectScreenshots\\drop2.png";
	public static void screenShotTC1(WebDriver driver){
		
		TakesScreenshot ts1=(TakesScreenshot)driver; 
		File source1=ts1.getScreenshotAs(OutputType.FILE);
		File target1= new File(filepath1);
		try {
			Files.copy(source1, target1);
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	  }
	
	public static void screenShotTC2(WebDriver driver){
		
		TakesScreenshot ts2=(TakesScreenshot)driver; 
		File source2=ts2.getScreenshotAs(OutputType.FILE);
		File target2= new File(filepath2);
		try {
			Files.copy(source2, target2);
		}catch(IOException e){
			System.out.println(e.getMessage());
		}
	  }

}

