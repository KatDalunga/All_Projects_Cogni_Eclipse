package testObjectRepo;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ProjectElements {
	public static WebElement element = null;
	public static WebDriver driver;

	public static WebElement source1Element(WebDriver driver) {
		element =driver.findElement(By.xpath("//div[@id='draggable']"));
    	return element;
    }
	
	public static WebElement target1Element(WebDriver driver) {
		element =driver.findElement(By.xpath("//*[@id='droppable']"));
    	return element;
    }
	
	public static WebElement datepickElement(WebDriver driver) {
		element =driver.findElement(By.xpath("//*[@id=\'datePickerMonthYearInput\']"));
    	return element;
    }
	
	public static List<WebElement> datepickDates(WebDriver driver){
		List<WebElement> alldates1 = driver.findElements(By.xpath("//div[@class='react-datepicker__month']/div/div"));
        return alldates1;
	}
	
	public static WebElement dtTimeElement(WebDriver driver) {
		element =driver.findElement(By.xpath("//*[@id='dateAndTimePickerInput']"));
    	return element;
    }
	
	public static List<WebElement> dtTimeDates(WebDriver driver){
		List<WebElement> alldates2 = driver.findElements(By.xpath("//div[@class='react-datepicker__month']//div"));
        return alldates2;
	}
	
	public static List<WebElement> allTimesList(WebDriver driver){
		List<WebElement> allTimes = driver.findElements(By.xpath("//div[@class='react-datepicker__time-box']//li"));
        return allTimes;
	}
	
	 
}
