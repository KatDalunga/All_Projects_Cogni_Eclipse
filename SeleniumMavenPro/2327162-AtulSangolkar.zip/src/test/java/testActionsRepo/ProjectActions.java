package testActionsRepo;


import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import testObjectRepo.ProjectElements;
import userDefinedLibraries.DriverSetup;
import userDefinedLibraries.ScreenShots;


public class ProjectActions extends DriverSetup {
	public static String browser = "Edge";
	public static String url_1 = "https://demoqa.com/droppable/";
	public static String url_2="https://demoqa.com/date-picker";
	public static WebDriver driver;
	
	public static void driverconfig1(String browser,String url)
    {
	 	//Instantiate driver for First page
		System.out.println("Instantiating browser with first url ..........");
    	driver=DriverSetup.driverInstantiate1(browser,url_1); 
    	System.out.println("URL opened Successfully in "+ browser + " Browser");
    }
	
	public static void performDragDrop()
    {
    	WebElement drag = ProjectElements.source1Element(driver);
    	WebElement drop = ProjectElements.target1Element(driver);
    	
    	System.out.println("Performing Drag and Drop Action..........");
    	
        Actions builder = new Actions(driver);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",drag);
        builder.moveToElement(drag);
        builder.clickAndHold(drag).moveToElement(drop).release(drag).build().perform();
        
        String s=drop.getText();
        System.out.println("The Element"+ s +"at Given Drop Box");
        
        System.out.println("Capturing ScreenShot for Drag and Drop ...............");
        try {
    		// Take screen shot for Drag and Drop
    		ScreenShots.screenShotTC1(driver);
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
        System.out.println("ScreenShot Captured Successfully!!!!!");
    }
	
	public static void driverconfig2(String browser,String url)
    {
	 	//Instantiate driver for Second page 
		System.out.println("Instantiating browser with Second url ..........");
    	driver=DriverSetup.driverInstantiate1(browser,url_2); 
    	System.out.println("URL opened Successfully in "+ browser + " Browser");
    	
    }

	public static void clickOnDate() {
		System.out.println("Searching for DateBox........");
		WebElement ClickOnTBox = ProjectElements.datepickElement(driver);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);",ClickOnTBox);
		ClickOnTBox.click();
		ClickOnTBox.clear();
		System.out.println("Successfully clicked on DateBox!!!");
		
	}
	
	static LocalDate nextDate= LocalDate.now().plusDays(1);
	static String formatedDate=nextDate.format(DateTimeFormatter.ofPattern("dd-MM-YYYY"));
	static String date=formatedDate.substring(0, 2);
	static String time="06:00";
	
	public static void selectDate() {
		System.out.println("Searching for Tomorrow's date.......");
		List <WebElement> all_dates = ProjectElements.datepickDates(driver);
		for(WebElement dt:all_dates) {
			if(dt.getText().equals(date)) {
				dt.click();
				break;
			}
		}
		System.out.println("Successfully clicked on Tomorrow's date");
	}
	
	public static void clickOnDateTime() {
		System.out.println("Searching for DateTimeBox........");
		WebElement ClickOnDTBox = ProjectElements.dtTimeElement(driver);
		ClickOnDTBox.click();
		ClickOnDTBox.clear();
		System.out.println("Clicked On DateTimeBox");
	}
	
	public static void selectDateTime() {
		System.out.println("Searching for given date.......");
		List <WebElement> all_dates1 = ProjectElements.dtTimeDates(driver);
		for(WebElement dt1:all_dates1) {
			if(dt1.getText().equals(date)) {
				dt1.click();
				break;
			}
		}
		System.out.println("Clicked on given date");
	}
	
	public static void selectTime() {
		System.out.println("Searching for given time ");
		List <WebElement> all_times = ProjectElements.allTimesList(driver);
		for(WebElement t:all_times) {
			if(t.getText().equals(time)) {
				t.click();
				break;
			}
		}
		System.out.println("Clicked on given Time ");
		
		
		System.out.println("Capturing ScreenShot for DatePicker...............");
        try {
    		// Take screen shot for Datepicker 
    		ScreenShots.screenShotTC2(driver);
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
        System.out.println("ScreenShot Captured Successfully!!!!!");
	}
	
	 public static void closeBrow()
	    {
	    	//Close the browser after all the steps of scenario
	    	driverTearDown();
	    	System.out.println("Closed the browser");
	    }
	
	
	
	public static void main(String[]args) {
		ProjectActions.driverconfig1(browser, url_1);
		ProjectActions.performDragDrop();
		ProjectActions.closeBrow();
		
		ProjectActions.driverconfig2(browser, url_2);
		ProjectActions.clickOnDate();
		ProjectActions.selectDate();
		ProjectActions.clickOnDateTime();
		ProjectActions.selectDateTime();
		ProjectActions.selectTime();
		ProjectActions.closeBrow();
		
	}

}
